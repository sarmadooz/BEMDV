/*
 * Mapping.h
 *
 *  Created on: 26.08.2008
 *      Author: Karl Wessel
 */

#ifndef MAPPING_H_
#define MAPPING_H_

#include "veins/base/phyLayer/MappingBase.h"
#include "veins/base/phyLayer/MappingUtils.h"


#endif /* MAPPING_H_ */
